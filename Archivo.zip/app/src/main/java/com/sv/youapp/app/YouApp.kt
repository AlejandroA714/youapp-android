package com.sv.youapp.app

import android.app.Application

class YouApp: Application()