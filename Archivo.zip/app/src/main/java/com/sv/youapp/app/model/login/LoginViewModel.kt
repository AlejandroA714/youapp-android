package com.sv.youapp.app.model.login

import androidx.lifecycle.ViewModel

class LoginViewModel: ViewModel() {


}